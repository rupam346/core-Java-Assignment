package com.cg.hsbc.CoreJavaAssignment;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class CoreJavaAssignment2 {

	public static void compareTwoTextFiles() throws IOException {
		
		File f1 = new File("C:\\Users\\RKUMA346\\eclipse-workspace\\cG_HSBC_training_Assignment\\RupamResume1.txt");
		File f2 = new File("C:\\Users\\RKUMA346\\eclipse-workspace\\cG_HSBC_training_Assignment\\RupamResume2.txt");
		
		FileReader r1 = new FileReader(f1);
		FileReader r2 = new FileReader(f2);

		BufferedReader reader1 = new BufferedReader(r1);
		BufferedReader reader2 = new BufferedReader(r2);
		
		String str1 = reader1.readLine();
		String str2 = reader2.readLine();
		
		boolean areEqual = false;
		int lineNum = 1;
		
		while(str1 != null  &&  str2 != null) {
			
			if(str1.equalsIgnoreCase(str2)) {
				areEqual = true;
				lineNum++;
			}
			else {
				areEqual = false;
				break;
			}
			str1 = reader1.readLine();
		    str2 = reader2.readLine();
		}
		if(areEqual) {
			System.out.println("File Matched");
		}else 
			System.out.println("File Mismatched at "+ lineNum+" line");
		}
	
	public static void main(String[] args)throws IOException {
		compareTwoTextFiles();
	}

}




